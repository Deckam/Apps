package com.example.a1_lab_pijus_veikauskas_mkdf20_4

import androidx.annotation.StringRes

data class Options(
    @StringRes val stringResourceId1: Int,
    @StringRes val stringResourceId: Int,
)