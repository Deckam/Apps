package com.example.a1_lab_pijus_veikauskas_mkdf20_4

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.isDigitsOnly
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.*
import com.example.a1_lab_pijus_veikauskas_mkdf20_4.ui.theme._1_Lab_Pijus_Šveikauskas_MKDF20_4Theme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            _1_Lab_Pijus_Šveikauskas_MKDF20_4Theme {
                Surface(modifier = Modifier
                    .fillMaxSize()
                    .wrapContentSize(Alignment.Center), color = MaterialTheme.colorScheme.background) {
                    MyApp()
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainPreview() {
    _1_Lab_Pijus_Šveikauskas_MKDF20_4Theme {
        MyApp(
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyApp() {
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = { TopAppBar(scrollBehavior = scrollBehavior) }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(it)
        ) {
            val navController = rememberNavController()
            NavHost(navController = navController, startDestination = "Main") {
                composable("Main") { Main(navController) }
                composable("CV") { CV(navController)  }
                composable("Portfolio") { Portfolio(navController)  }
                composable("Forma") { Forma(navController)  }

            }
        }
    }
}

var lt by mutableStateOf(true)

@Composable
fun Main(navController: NavController, modifier: Modifier = Modifier) {

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier) {
        item {
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = modifier
            ) {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = stringResource(R.string.message),
                    fontSize = 54.sp,
                    lineHeight = 70.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(1.dp)

                )
                if(lt) {
                    Text(
                        text = stringResource(R.string.from),
                        fontSize = 18.sp,
                        modifier = Modifier
                            .padding(1.dp)
                    )
                }
                else {
                    Text(
                        text = stringResource(R.string.efrom),
                        fontSize = 18.sp,
                        modifier = Modifier
                            .padding(1.dp)
                    )

                }
                Spacer(modifier = Modifier.height(20.dp))
                Image(
                    painter = painterResource(R.drawable.my_photo),
                    contentDescription = toString()
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = stringResource(R.string.el),
                    fontSize = 18.sp,
                    modifier = Modifier
                        .padding(1.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))

                var click by remember { mutableStateOf(false) }
                val buttonColor by rememberUpdatedState(
                    if (click) Color.White else Color.Black
                )
                val coroutineScope1 = rememberCoroutineScope()

                Button(onClick = {
                    navController.navigate("CV"); click = true
                    coroutineScope1.launch {
                        delay(150)
                        click = false
                    }
                }
                ) {
                    Text(
                        text = stringResource(R.string.go1),
                        fontSize = 24.sp,
                        color = (buttonColor)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Button(onClick = {
                    navController.navigate("Portfolio"); click = true
                    coroutineScope1.launch {
                        delay(150)
                        click = false
                    }
                }
                ) {
                    Text(
                        text = stringResource(R.string.go2),
                        fontSize = 24.sp,
                        color = (buttonColor)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Button(onClick = {
                    navController.navigate("Forma"); click = true
                    coroutineScope1.launch {
                        delay(150)
                        click = false
                    }
                }
                ) {
                    if (lt) {
                        Text(
                            text = stringResource(R.string.go3),
                            fontSize = 24.sp,
                            color = (buttonColor)
                        )
                    }
                    else{
                        Text(
                            text = stringResource(R.string.ego3),
                            fontSize = 24.sp,
                            color = (buttonColor)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
                if (lt) {
                    Text(
                        text = "Atsisiūskite šia vizitinę",
                        fontSize = 24.sp,
                    )
                }
                else{
                    Text(
                        text = "Download this app",
                        fontSize = 24.sp,
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Image(
                    painter = painterResource(R.drawable.qr_github),
                    contentDescription = toString()
                )
                Spacer(modifier = Modifier.height(20.dp))

            }
        }
    }
}

@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CV (navController: NavController, modifier: Modifier = Modifier) {

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier) {
        item {
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = modifier
                    .padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.message),
                    fontSize = 40.sp,
                    lineHeight = 50.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(2.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))
                if(lt) {
                    Text(
                        text = "Gyvenimo aprašymas:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                else {
                    Text(
                        text = "Life overview:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                if(lt) {
                    Text(
                        text = "Gimiau ir didžiaja gyvenimo dalį gyvenau Šiauliuose. Dabar studijuoju Vilniuje, bet dažnai savaitgaliais parvažiuoju į Šiaulius.",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                else {
                    Text(
                        text = "I was born and lived in Šiauliai for most of my life. Now I am studying in Vilnius, but often on weekends I drive back to Šiauliai.",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                if(lt) {
                    Text(
                        text = "Išsilavinimas:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                else {
                    Text(
                        text = "Education:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                if(lt) {
                    Text(
                        text = "• Baigiau Šiaulių Jovaro progimnaziją\n" +
                                "• Baigiau Šiaulių Didždvario gimnaziją\n" +
                                "• Baigiau Šiaulių dailės mokyklą",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                else {
                    Text(
                        text = "• Finished Šiaulių Jovaro progimnasium\n" +
                                "• Finished Šiaulių Didždvario gimnazium\n" +
                                "• Finished Šiaulių art school",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                if(lt) {
                    Text(
                        text = "Darbovietės:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                else {
                    Text(
                        text = "Workplaces:",
                        fontSize = 28.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                if(lt) {
                    Text(
                        text = "• Dirbu savanoriu kareiviu KASP pajėgose\n" +
                                "• Dirbau pripučiamų atrakcijonų prižiurėtoju\n" +
                                "• Dirbau turėklų montuotoju statybvietėje, Norvegijoje",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                else {
                    Text(
                        text = "• I work as a volunteer soldier in the KASP forces\n" +
                                "• I worked as an inflatable attraction caretaker\n" +
                                "• I worked as a railing installer on a construction site in Norway",
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(3.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))

                val context = LocalContext.current
                val sharedPreferences = remember { context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE) }
                var note by remember { mutableStateOf(sharedPreferences.getString("note", "")) }

                if (note != null) {
                    TextField(
                        value = note!!,
                        onValueChange = {
                            note = it
                            saveNotes(context, note!!)
                        },
                        label = {
                            if (lt) {Text("Užrašai:")}
                            else {Text("Notes:")}
                             },
                        keyboardOptions = KeyboardOptions.Default.copy(
                        )
                    )
                }
            }
        }
    }

}

fun saveNotes(context: Context, note: String) {
    val sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    sharedPreferences.edit().putString("note", note).apply()
}

@Composable
fun Portfolio (navController: NavController, modifier: Modifier = Modifier) {

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier) {
        item {
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = modifier
                    .padding(16.dp)
            ) {
                Text(
                    text = "Portfolio",
                    fontSize = 42.sp,
                    modifier = Modifier
                        .padding(2.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))
                if (lt) {
                    Text(
                        text = "3D Modeliai:",
                        fontSize = 32.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                } else {
                    Text(
                        text = "3D Models: ",
                        fontSize = 32.sp,
                        modifier = Modifier
                            .padding(2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Image(
                    painter = painterResource(R.drawable.mod1),
                    contentDescription = toString(),
                    modifier = Modifier
                        .fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                Image(
                    painter = painterResource(R.drawable.mod2),
                    contentDescription = toString(),
                    modifier = Modifier
                        .fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                Image(
                    painter = painterResource(R.drawable.mod3),
                    contentDescription = toString(),
                    modifier = Modifier
                        .fillMaxWidth()
                )

            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Forma (navController: NavController, modifier: Modifier = Modifier){
    var numberText by remember { mutableStateOf("") }
    var nameText by remember { mutableStateOf("") }
    var infoText by remember { mutableStateOf("") }
    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier) {
        item {
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Spacer(modifier = Modifier.height(30.dp))
        if (lt) {
            Text(
                text = "Užpildykite duomenis",
                fontSize = 34.sp,
                modifier = Modifier
                    .padding(1.dp)
            )
        } else {
            Text(
                text = "Fill in the fields",
                fontSize = 34.sp,
                modifier = Modifier
                    .padding(1.dp)
            )
        }
        Spacer(modifier = Modifier.height(30.dp))
        Row(modifier = modifier) {
            TextField(
                value = numberText,
                onValueChange = {
                    if (it.isEmpty() || it.isDigitsOnly()) {
                        numberText = it
                    }
                },
                label = {
                    if (lt) {
                        Text("Jūsų telefono nr.")
                    } else {
                        Text("Your phone num.")
                    }
                },
                placeholder = { Text("860000000") },
                keyboardOptions = KeyboardOptions.Default.copy(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.width(200.dp)
            )
            TextField(
                value = nameText,
                onValueChange = {
                    nameText = it
                },
                label = {
                    if (lt) {
                        Text("Jūsu Vardas")
                    } else {
                        Text("Your name")
                    }
                },
                keyboardOptions = KeyboardOptions.Default.copy(
                ),
                modifier = Modifier
                    .width(200.dp)
            )
                }
        Spacer(modifier = Modifier.height(10.dp))

        TextField(
            value = infoText,
            onValueChange = {
                infoText = it
            },
            label = {
                if (lt) {
                    Text("Žinutė:")
                } else {
                    Text("Note:")
                }
            },
            keyboardOptions = KeyboardOptions.Default.copy(
            ),
            modifier = Modifier
                .fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(300.dp))

        ShareButton(emailAddress = "pijus.sveikauskas@stud.vilniustech.lt", shareText =
                "Siuntėjas: " + nameText +
                "\n Telefono numeris: " + numberText +
                "\n Žinutė: "+ infoText)
            }
        }
    }
}

@Composable
fun ShareButton(emailAddress: String, shareText: String) {
    val context = LocalContext.current
    var click by remember { mutableStateOf(false) }
    val buttonColor by rememberUpdatedState(if (click) Color.White else Color.Black)
    val coroutineScope1 = rememberCoroutineScope()

    Button(onClick = {
        val intent = Intent(Intent.ACTION_SEND).apply {
            data = Uri.parse("mailto:$emailAddress")
            putExtra(Intent.EXTRA_SUBJECT, "Žinutė iš vizitinės kortelės")
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        click = true
        context.startActivity(
            Intent.createChooser(
                intent,
                "Send"
            )
        )
        coroutineScope1.launch {
            delay(150)
            click = false }
    })
    {
        if(lt){ Text(
            text = "Siūsti",
            fontSize = 24.sp,
            color = (buttonColor))}
        else{ Text(
            text = "Share",
            fontSize = 24.sp,
            color = (buttonColor))}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBar(scrollBehavior: TopAppBarScrollBehavior, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    CenterAlignedTopAppBar(
        scrollBehavior = scrollBehavior,
        title = {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
            )
        },
        actions = {
            IconButton(onClick = { expanded = true }) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = "Localized description"
                )
            }
            if (expanded==true){
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    Column(){
                        Box(
                            modifier = Modifier
                                .size(250.dp, 50.dp)
                                .padding(3.dp)
                                .clickable {
                                    expanded = false
                                    lt = true
                                }
                        ) {
                            Text(text=" Lt", fontSize = 25.sp)
                        }
                        Box(
                            modifier = Modifier
                                .size(250.dp, 50.dp)
                                .padding(3.dp)
                                .clickable {
                                    expanded = false
                                    lt = false
                                }
                        ) {
                            Text(text=" En", fontSize = 25.sp)
                        }
                    }

                }
            }
        },
        modifier = Modifier.fillMaxWidth()

    )
}
